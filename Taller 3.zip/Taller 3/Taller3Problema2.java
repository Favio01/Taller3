package taller.pkg3.problema.pkg2;

import java.util.Random;

public class Taller3Problema2 {

    public static void main(String[] args) {
        String edificios[] = {"DICI", "RA", "R1", "D", "E", "DIS"};
        int moneda = 0;
        int contEdif = 0;

        do {
            moneda = (int) (Math.random() * 2 + 1);
            if (moneda == 2) {
                System.out.println("La moneda a salido Cara");
                System.out.println("se a quedado en el edificio " + edificios[contEdif]);
            } else {
                System.out.println("La moneda a salido Cruz");
                System.out.println("Continua caminando");
            }
            contEdif++;
        } while (moneda < 2);
        System.out.println("");
        System.out.println("Fin del programa");
    }

}
