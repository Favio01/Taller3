
package taller.pkg3.problema.pkg1;
import java.util.Scanner;
public class Taller3Problema1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int horasExtra;
        int pagoHorasExtra = 0;
        int pagoHoras = 0;
        int horas;
        double bonificacion = 0;
        double pagoPorBonif = 0;
        int ventas;
        int gananciaSemanal = 0;
        int ganaciaMensual = 0;
        
        System.out.println("Ingrese las horas que trabajo a la semana");
        horas = sc.nextInt();
        
        System.out.println("Ingrese el monto en ventas");
        ventas = sc.nextInt();
        
        if (horas > 40) {
            horasExtra = horas - 40;
            pagoHorasExtra = 3000 * horasExtra;
        }else{
            pagoHoras = 2000 * horas;
        }
        
        if((ventas > 300000) && (ventas <=500000)){
            bonificacion = 0.05;
        }
        if(ventas >500000){
            bonificacion = 0.10;
        }
        pagoPorBonif = ventas * bonificacion;
        gananciaSemanal = pagoHoras + pagoHorasExtra;
        ganaciaMensual = gananciaSemanal * 4;
        
        System.out.println("las ganacias semanales son: " + gananciaSemanal);
        System.out.println("las ganacias mensuales son: " + ganaciaMensual);
       
        
    }
    
}
