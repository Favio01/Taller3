package taller.pkg3.problema.pkg3;

import java.util.Scanner;

public class Taller3Problema3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String opcion_Resumen_Caracteristica[] = new String[5];
        int valor_Pizza = 0;
        int opcion_Agregado_Tipo;

        System.out.println("Ingrese una opcion");
        System.out.println("Tamaño de pizza");
        System.out.println("1. pizza mediana : $2400");
        System.out.println("2. pizza Familiar : $3200");
        opcion_Agregado_Tipo = sc.nextInt();

        if (opcion_Agregado_Tipo == 1) {
            valor_Pizza = valor_Pizza + 2400;
            opcion_Resumen_Caracteristica[0] = "Tamaño Pizza | Pizza mediana : queso y salsa de tomate";
        } else {
            if (opcion_Agregado_Tipo == 2) {
                valor_Pizza = valor_Pizza + 3200;
                opcion_Resumen_Caracteristica[0] = "Tamaño Pizza | Pizza familiar : queso y salsa de tomate";

            }
        }

        System.out.println("Ingrese una opcion");
        System.out.println("1. Pizza vegetariana");
        System.out.println("2. Pizza normal");
        opcion_Agregado_Tipo = sc.nextInt();

        if (opcion_Agregado_Tipo == 1) {
            opcion_Resumen_Caracteristica[1] = "Tipo Pizza | Pizza vegetariana";
            System.out.println("ingrese una opcion");
            System.out.println("1. Champiñones : $1200");
            System.out.println("2. Carne de soya : $1000");
            opcion_Agregado_Tipo = sc.nextInt();

            if (opcion_Agregado_Tipo == 1) {
                opcion_Resumen_Caracteristica[2] = "Agregado de : Champiñones";
                valor_Pizza = valor_Pizza + 1200;
            } else {
                if (opcion_Agregado_Tipo == 2) {
                    opcion_Resumen_Caracteristica[2] = "Agregado de : Carne de soya";
                    valor_Pizza = valor_Pizza + 1000;
                }
            }
            System.out.println("porcion extra:");
            System.out.println("1. aceitunas : $300");
            opcion_Agregado_Tipo = sc.nextInt();

            if (opcion_Agregado_Tipo == 1) {
                opcion_Resumen_Caracteristica[4] = "Porcion extra : Aceitunas";
                valor_Pizza = valor_Pizza + 300;
            }

        } else {
            if (opcion_Agregado_Tipo == 2) {
                opcion_Resumen_Caracteristica[1] = "Tipo Pizza | Pizza Normal";
                System.out.println("Ingrese una opcion");
                System.out.println("1. jamón : $1000");
                System.out.println("2. salame : $1000");
                System.out.println("3. jamon y Salame : $1500");
                opcion_Agregado_Tipo = sc.nextInt();

                if (opcion_Agregado_Tipo == 1) {
                    opcion_Resumen_Caracteristica[2] = "Agregado de : jamón";
                    valor_Pizza = valor_Pizza + 1000;
                } else {
                    if (opcion_Agregado_Tipo == 2) {
                        opcion_Resumen_Caracteristica[2] = "Agregado de : Salame";
                        valor_Pizza = valor_Pizza + 1000;
                    } else {
                        if (opcion_Agregado_Tipo == 3) {
                            opcion_Resumen_Caracteristica[2] = "Agregado de : Jamón y Salame";
                            valor_Pizza = valor_Pizza + 1500;
                        }
                    }
                }

                System.out.println("porcion extra:");
                System.out.println("1. Champiñones : $500");
                opcion_Agregado_Tipo = sc.nextInt();

                if (opcion_Agregado_Tipo == 1) {
                    opcion_Resumen_Caracteristica[4] = "Porcion extra : Champiñones";
                    valor_Pizza = valor_Pizza + 500;
                }

            }
        }

        System.out.println("Mezcla de verduras y vegetales:");
        System.out.println("1. tomate, choclo, pimiento verde : $1500");
        System.out.println("2. cebollas fritas, pimiento rojo, tomate, choclo : $2500");
        System.out.println("3. palmito, pimiento verde : $1000");
        opcion_Agregado_Tipo = sc.nextInt();

        if (opcion_Agregado_Tipo == 1) {
            opcion_Resumen_Caracteristica[3] = "Agregado de verduras y vegetales : tomate, choclo, pimiento verde";
            valor_Pizza = valor_Pizza + 1500;
        } else {
            if (opcion_Agregado_Tipo == 2) {
                opcion_Resumen_Caracteristica[3] = "Agregado de verduras y vegetales : cebollas fritas, pimiento rojo, tomate, choclo";
                valor_Pizza = valor_Pizza + 2500;
            } else {
                if (opcion_Agregado_Tipo == 3) {
                    opcion_Resumen_Caracteristica[3] = "Agregado de verduras y vegetales : palmito, pimiento verde";
                    valor_Pizza = valor_Pizza + 1000;
                }
            }
        }

        System.out.println("Resumen decaracteristicas de la Pizza pedida:");
        for (int i = 0; i < 5; i++) {
            System.out.println(opcion_Resumen_Caracteristica[i]);
        }
        System.out.println("El valor final de la pizza es: " + valor_Pizza);

    }

}
